"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const express_1 = tslib_1.__importDefault(require("express"));
const http_1 = tslib_1.__importDefault(require("http"));
const path_1 = tslib_1.__importDefault(require("path"));
const socket_io_1 = require("socket.io");
const cors_1 = tslib_1.__importDefault(require("cors"));
const helmet_1 = tslib_1.__importDefault(require("helmet"));
const express_rate_limit_1 = tslib_1.__importDefault(require("express-rate-limit"));
const prisma_1 = tslib_1.__importDefault(require("./lib/prisma"));
const authService_1 = require("./services/authService");
// Importar rutas
const auth_1 = tslib_1.__importDefault(require("./routes/auth"));
const products_1 = tslib_1.__importDefault(require("./routes/products"));
const orders_1 = tslib_1.__importDefault(require("./routes/orders"));
const upload_1 = tslib_1.__importDefault(require("./routes/upload"));
const branches_1 = tslib_1.__importDefault(require("./routes/api/branches"));
const adminProducts_1 = tslib_1.__importDefault(require("./routes/adminProducts"));
const offers_1 = tslib_1.__importDefault(require("./routes/offers"));
const slideshow_1 = tslib_1.__importDefault(require("./routes/slideshow"));
const wholesaleProductRoutes = require('../routes/wholesaleProducts');
const app = (0, express_1.default)();
const server = http_1.default.createServer(app);
const io = new socket_io_1.Server(server, {
    cors: {
        origin: [
            "https://www.marvera.mx", // ✅ PRINCIPAL
            "https://marvera.mx", // ✅ SECUNDARIO
            "http://www.marvera.mx", // ✅ DESARROLLO
            "http://marvera.mx",
            "http://localhost:5173",
            "http://localhost:5174"
        ],
        methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        credentials: true
    }
});
const PORT = process.env.PORT || 3001; // 🔧 PUERTO UNIFICADO: 3001
// Middleware de seguridad
app.use((0, helmet_1.default)({
    crossOriginResourcePolicy: { policy: "cross-origin" },
    contentSecurityPolicy: {
        directives: {
            ...helmet_1.default.contentSecurityPolicy.getDefaultDirectives(),
            "img-src": ["'self'", "data:", "blob:", "*"],
        },
    },
}));
// Rate limiting - más permisivo en desarrollo
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 1 * 60 * 1000, // 1 minuto en lugar de 15
    max: process.env.NODE_ENV === 'production' ? 100 : 1000, // 1000 requests en desarrollo, 100 en producción
    message: {
        success: false,
        message: 'Demasiadas peticiones, intenta de nuevo más tarde'
    },
    skip: (req) => {
        // Saltar rate limiting para desarrollo local
        const isLocalhost = req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1';
        const isDevelopment = process.env.NODE_ENV === 'development';
        return isDevelopment || isLocalhost;
    }
});
// Solo aplicar rate limiting en producción
if (process.env.NODE_ENV === 'production') {
    app.use(limiter);
}
else {
    console.log('🔓 Rate limiting deshabilitado en desarrollo');
}
// CORS
app.use((0, cors_1.default)({
    origin: [
        'https://www.marvera.mx', // ✅ PRINCIPAL
        'https://marvera.mx', // ✅ SECUNDARIO  
        'http://www.marvera.mx', // ✅ DESARROLLO
        'http://marvera.mx',
        'http://localhost:5173',
        'http://localhost:5174'
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
// Handle preflight requests
app.options('*', (0, cors_1.default)());
// Body parser - Aumentar límites para uploads
app.use(express_1.default.json({ limit: '50mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '50mb' }));
// Middleware para CORS en archivos estáticos
app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Cross-Origin-Resource-Policy', 'cross-origin');
    res.header('Cross-Origin-Embedder-Policy', 'unsafe-none');
    next();
});
// Servir archivos estáticos (imágenes subidas)
app.use('/uploads', express_1.default.static(path_1.default.join(__dirname, '../uploads')));
// Rutas de la API
app.use('/api/auth', auth_1.default);
app.use('/api/products', products_1.default);
app.use('/api/orders', orders_1.default);
app.use('/api/upload', upload_1.default);
app.use('/api/branches', branches_1.default);
app.use('/api/admin/products', adminProducts_1.default);
app.use('/api/wholesale-products', wholesaleProductRoutes);
app.use('/api', offers_1.default);
app.use('/api/slideshow', slideshow_1.default);
// Ruta de health check
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'MarVera API funcionando correctamente',
        timestamp: new Date().toISOString()
    });
});
// Socket.IO para tracking en tiempo real
io.on('connection', (socket) => {
    console.log('Cliente conectado:', socket.id);
    // Unirse a sala de seguimiento de pedido
    socket.on('track-order', (orderId) => {
        socket.join(`order-${orderId}`);
        console.log(`Cliente ${socket.id} siguiendo pedido ${orderId}`);
    });
    // Actualización de ubicación del conductor
    socket.on('driver-location-update', (data) => {
        const { orderId, latitude, longitude, driverId } = data;
        // Broadcast a todos los clientes siguiendo este pedido
        socket.to(`order-${orderId}`).emit('location-update', {
            latitude,
            longitude,
            driverId,
            timestamp: new Date().toISOString()
        });
        console.log(`Ubicación actualizada para pedido ${orderId}: ${latitude}, ${longitude}`);
    });
    // Actualización de estado del pedido
    socket.on('order-status-update', (data) => {
        const { orderId, status, message } = data;
        socket.to(`order-${orderId}`).emit('status-update', {
            status,
            message,
            timestamp: new Date().toISOString()
        });
        console.log(`Estado actualizado para pedido ${orderId}: ${status}`);
    });
    socket.on('disconnect', () => {
        console.log('Cliente desconectado:', socket.id);
    });
});
// Simulador de datos de tracking (para demo)
setInterval(() => {
    // Simular actualización de ubicación para demo
    const demoOrderId = 1;
    const demoLat = -12.0464 + (Math.random() - 0.5) * 0.01;
    const demoLng = -77.0428 + (Math.random() - 0.5) * 0.01;
    io.to(`order-${demoOrderId}`).emit('location-update', {
        latitude: demoLat,
        longitude: demoLng,
        driverId: 1,
        timestamp: new Date().toISOString()
    });
}, 5000); // Cada 5 segundos
// Manejo de errores
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({
        success: false,
        message: 'Error interno del servidor'
    });
});
// Manejar rutas no encontradas
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Ruta no encontrada'
    });
});
server.listen(PORT, async () => {
    console.log(`🚀 Servidor MarVera corriendo en puerto ${PORT} en todas las interfaces`);
    console.log(`📊 API disponible en http://localhost:${PORT}/api`);
    console.log(`🌐 API disponible externamente en https://www.marvera.mx/api`);
    console.log(`🔌 Socket.IO habilitado para tracking en tiempo real`);
    console.log(`💾 Prisma conectado a la base de datos SQLite`);
    // Verificar conexión con Prisma
    try {
        await prisma_1.default.$connect();
        console.log('✅ Conexión a Prisma establecida correctamente');
        // Crear usuario admin por defecto
        await authService_1.AuthService.createAdminUser();
    }
    catch (error) {
        console.error('❌ Error conectando a Prisma:', error);
    }
});
//# sourceMappingURL=index.js.map