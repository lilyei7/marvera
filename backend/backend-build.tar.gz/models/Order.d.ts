declare const _exports: mongoose.Model<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    items: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    statusHistory: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    orderNumber?: unknown;
    userId?: mongoose.Types.ObjectId | null | undefined;
    status?: unknown;
    subtotal?: unknown;
    shippingCost?: unknown;
    tax?: unknown;
    paymentMethod?: unknown;
    paymentStatus?: unknown;
    shippingAddress?: {
        name?: unknown;
        phone?: unknown;
        address?: unknown;
        city?: unknown;
        state?: unknown;
        postalCode?: unknown;
        instructions?: unknown;
        country?: unknown;
    } | null | undefined;
    notes?: unknown;
    type?: unknown;
    paymentId?: unknown;
    billingAddress?: unknown;
    preferredDeliveryDate?: unknown;
    estimatedDelivery?: unknown;
    actualDelivery?: unknown;
    trackingNumber?: unknown;
    courierService?: unknown;
    specialInstructions?: unknown;
    customerNotes?: unknown;
    internalNotes?: unknown;
    cancelledAt?: unknown;
    cancelReason?: unknown;
    refundReason?: unknown;
    refundedAt?: unknown;
    discount?: unknown;
    totalAmount?: unknown;
    currency?: unknown;
    deliveryMethod?: unknown;
    preferredDeliveryTime?: unknown;
    isWholesale?: unknown;
    wholesaleDetails?: unknown;
    loyaltyPointsUsed?: unknown;
    loyaltyPointsEarned?: unknown;
    rating?: unknown;
    refundAmount?: unknown;
}, {}, {}, {}, mongoose.Document<unknown, {}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    items: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    statusHistory: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    orderNumber?: unknown;
    userId?: mongoose.Types.ObjectId | null | undefined;
    status?: unknown;
    subtotal?: unknown;
    shippingCost?: unknown;
    tax?: unknown;
    paymentMethod?: unknown;
    paymentStatus?: unknown;
    shippingAddress?: {
        name?: unknown;
        phone?: unknown;
        address?: unknown;
        city?: unknown;
        state?: unknown;
        postalCode?: unknown;
        instructions?: unknown;
        country?: unknown;
    } | null | undefined;
    notes?: unknown;
    type?: unknown;
    paymentId?: unknown;
    billingAddress?: unknown;
    preferredDeliveryDate?: unknown;
    estimatedDelivery?: unknown;
    actualDelivery?: unknown;
    trackingNumber?: unknown;
    courierService?: unknown;
    specialInstructions?: unknown;
    customerNotes?: unknown;
    internalNotes?: unknown;
    cancelledAt?: unknown;
    cancelReason?: unknown;
    refundReason?: unknown;
    refundedAt?: unknown;
    discount?: unknown;
    totalAmount?: unknown;
    currency?: unknown;
    deliveryMethod?: unknown;
    preferredDeliveryTime?: unknown;
    isWholesale?: unknown;
    wholesaleDetails?: unknown;
    loyaltyPointsUsed?: unknown;
    loyaltyPointsEarned?: unknown;
    rating?: unknown;
    refundAmount?: unknown;
}, {}, {
    timestamps: true;
    toJSON: {
        transform: (doc: mongoose.Document<unknown, {}, mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }, ret: mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }) => mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        };
    };
}> & {
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    items: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    statusHistory: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    orderNumber?: unknown;
    userId?: mongoose.Types.ObjectId | null | undefined;
    status?: unknown;
    subtotal?: unknown;
    shippingCost?: unknown;
    tax?: unknown;
    paymentMethod?: unknown;
    paymentStatus?: unknown;
    shippingAddress?: {
        name?: unknown;
        phone?: unknown;
        address?: unknown;
        city?: unknown;
        state?: unknown;
        postalCode?: unknown;
        instructions?: unknown;
        country?: unknown;
    } | null | undefined;
    notes?: unknown;
    type?: unknown;
    paymentId?: unknown;
    billingAddress?: unknown;
    preferredDeliveryDate?: unknown;
    estimatedDelivery?: unknown;
    actualDelivery?: unknown;
    trackingNumber?: unknown;
    courierService?: unknown;
    specialInstructions?: unknown;
    customerNotes?: unknown;
    internalNotes?: unknown;
    cancelledAt?: unknown;
    cancelReason?: unknown;
    refundReason?: unknown;
    refundedAt?: unknown;
    discount?: unknown;
    totalAmount?: unknown;
    currency?: unknown;
    deliveryMethod?: unknown;
    preferredDeliveryTime?: unknown;
    isWholesale?: unknown;
    wholesaleDetails?: unknown;
    loyaltyPointsUsed?: unknown;
    loyaltyPointsEarned?: unknown;
    rating?: unknown;
    refundAmount?: unknown;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    toJSON: {
        transform: (doc: mongoose.Document<unknown, {}, mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }, ret: mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }) => mongoose.FlatRecord<{
            orderNumber: string;
            userId: mongoose.Types.ObjectId;
            status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
            subtotal: number;
            shippingCost: number;
            tax: number;
            paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
            paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
            shippingAddress: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            };
            items: mongoose.Types.DocumentArray<{
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }> & {
                name: string;
                price: number;
                quantity: number;
                productId: mongoose.Types.ObjectId;
                weight?: number | null | undefined;
                specifications?: {
                    notes?: string | null | undefined;
                    size?: string | null | undefined;
                    preparation?: string | null | undefined;
                } | null | undefined;
            }>;
            type: "retail" | "wholesale";
            discount: number;
            totalAmount: number;
            currency: "MXN" | "USD";
            deliveryMethod: "delivery" | "pickup" | "shipping";
            statusHistory: mongoose.Types.DocumentArray<{
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }> & {
                status: string;
                timestamp: NativeDate;
                notes?: string | null | undefined;
                updatedBy?: mongoose.Types.ObjectId | null | undefined;
            }>;
            isWholesale: boolean;
            loyaltyPointsUsed: number;
            loyaltyPointsEarned: number;
            refundAmount: number;
            notes?: string | null | undefined;
            paymentId?: string | null | undefined;
            billingAddress?: {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                country: string;
                instructions?: string | null | undefined;
            } | null | undefined;
            preferredDeliveryDate?: NativeDate | null | undefined;
            estimatedDelivery?: NativeDate | null | undefined;
            actualDelivery?: NativeDate | null | undefined;
            trackingNumber?: string | null | undefined;
            courierService?: string | null | undefined;
            specialInstructions?: string | null | undefined;
            customerNotes?: string | null | undefined;
            internalNotes?: string | null | undefined;
            cancelledAt?: NativeDate | null | undefined;
            cancelReason?: string | null | undefined;
            refundReason?: string | null | undefined;
            refundedAt?: NativeDate | null | undefined;
            preferredDeliveryTime?: {
                end?: string | null | undefined;
                start?: string | null | undefined;
            } | null | undefined;
            wholesaleDetails?: {
                businessName?: string | null | undefined;
                taxId?: string | null | undefined;
                discountPercentage?: number | null | undefined;
            } | null | undefined;
            rating?: {
                comment?: string | null | undefined;
                ratedAt?: NativeDate | null | undefined;
                score?: number | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        };
    };
}, {
    orderNumber: string;
    userId: mongoose.Types.ObjectId;
    status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
    subtotal: number;
    shippingCost: number;
    tax: number;
    paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
    paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
    shippingAddress: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    };
    items: mongoose.Types.DocumentArray<{
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }> & {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }>;
    type: "retail" | "wholesale";
    discount: number;
    totalAmount: number;
    currency: "MXN" | "USD";
    deliveryMethod: "delivery" | "pickup" | "shipping";
    statusHistory: mongoose.Types.DocumentArray<{
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }> & {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }>;
    isWholesale: boolean;
    loyaltyPointsUsed: number;
    loyaltyPointsEarned: number;
    refundAmount: number;
    notes?: string | null | undefined;
    paymentId?: string | null | undefined;
    billingAddress?: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    } | null | undefined;
    preferredDeliveryDate?: NativeDate | null | undefined;
    estimatedDelivery?: NativeDate | null | undefined;
    actualDelivery?: NativeDate | null | undefined;
    trackingNumber?: string | null | undefined;
    courierService?: string | null | undefined;
    specialInstructions?: string | null | undefined;
    customerNotes?: string | null | undefined;
    internalNotes?: string | null | undefined;
    cancelledAt?: NativeDate | null | undefined;
    cancelReason?: string | null | undefined;
    refundReason?: string | null | undefined;
    refundedAt?: NativeDate | null | undefined;
    preferredDeliveryTime?: {
        end?: string | null | undefined;
        start?: string | null | undefined;
    } | null | undefined;
    wholesaleDetails?: {
        businessName?: string | null | undefined;
        taxId?: string | null | undefined;
        discountPercentage?: number | null | undefined;
    } | null | undefined;
    rating?: {
        comment?: string | null | undefined;
        ratedAt?: NativeDate | null | undefined;
        score?: number | null | undefined;
    } | null | undefined;
}, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    orderNumber: string;
    userId: mongoose.Types.ObjectId;
    status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
    subtotal: number;
    shippingCost: number;
    tax: number;
    paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
    paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
    shippingAddress: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    };
    items: mongoose.Types.DocumentArray<{
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }> & {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }>;
    type: "retail" | "wholesale";
    discount: number;
    totalAmount: number;
    currency: "MXN" | "USD";
    deliveryMethod: "delivery" | "pickup" | "shipping";
    statusHistory: mongoose.Types.DocumentArray<{
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }> & {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }>;
    isWholesale: boolean;
    loyaltyPointsUsed: number;
    loyaltyPointsEarned: number;
    refundAmount: number;
    notes?: string | null | undefined;
    paymentId?: string | null | undefined;
    billingAddress?: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    } | null | undefined;
    preferredDeliveryDate?: NativeDate | null | undefined;
    estimatedDelivery?: NativeDate | null | undefined;
    actualDelivery?: NativeDate | null | undefined;
    trackingNumber?: string | null | undefined;
    courierService?: string | null | undefined;
    specialInstructions?: string | null | undefined;
    customerNotes?: string | null | undefined;
    internalNotes?: string | null | undefined;
    cancelledAt?: NativeDate | null | undefined;
    cancelReason?: string | null | undefined;
    refundReason?: string | null | undefined;
    refundedAt?: NativeDate | null | undefined;
    preferredDeliveryTime?: {
        end?: string | null | undefined;
        start?: string | null | undefined;
    } | null | undefined;
    wholesaleDetails?: {
        businessName?: string | null | undefined;
        taxId?: string | null | undefined;
        discountPercentage?: number | null | undefined;
    } | null | undefined;
    rating?: {
        comment?: string | null | undefined;
        ratedAt?: NativeDate | null | undefined;
        score?: number | null | undefined;
    } | null | undefined;
}>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
    orderNumber: string;
    userId: mongoose.Types.ObjectId;
    status: "pending" | "confirmed" | "preparing" | "shipped" | "delivered" | "cancelled" | "refunded" | "processing" | "ready";
    subtotal: number;
    shippingCost: number;
    tax: number;
    paymentMethod: "cash" | "card" | "transfer" | "paypal" | "stripe";
    paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partial";
    shippingAddress: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    };
    items: mongoose.Types.DocumentArray<{
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }> & {
        name: string;
        price: number;
        quantity: number;
        productId: mongoose.Types.ObjectId;
        weight?: number | null | undefined;
        specifications?: {
            notes?: string | null | undefined;
            size?: string | null | undefined;
            preparation?: string | null | undefined;
        } | null | undefined;
    }>;
    type: "retail" | "wholesale";
    discount: number;
    totalAmount: number;
    currency: "MXN" | "USD";
    deliveryMethod: "delivery" | "pickup" | "shipping";
    statusHistory: mongoose.Types.DocumentArray<{
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }> & {
        status: string;
        timestamp: NativeDate;
        notes?: string | null | undefined;
        updatedBy?: mongoose.Types.ObjectId | null | undefined;
    }>;
    isWholesale: boolean;
    loyaltyPointsUsed: number;
    loyaltyPointsEarned: number;
    refundAmount: number;
    notes?: string | null | undefined;
    paymentId?: string | null | undefined;
    billingAddress?: {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        country: string;
        instructions?: string | null | undefined;
    } | null | undefined;
    preferredDeliveryDate?: NativeDate | null | undefined;
    estimatedDelivery?: NativeDate | null | undefined;
    actualDelivery?: NativeDate | null | undefined;
    trackingNumber?: string | null | undefined;
    courierService?: string | null | undefined;
    specialInstructions?: string | null | undefined;
    customerNotes?: string | null | undefined;
    internalNotes?: string | null | undefined;
    cancelledAt?: NativeDate | null | undefined;
    cancelReason?: string | null | undefined;
    refundReason?: string | null | undefined;
    refundedAt?: NativeDate | null | undefined;
    preferredDeliveryTime?: {
        end?: string | null | undefined;
        start?: string | null | undefined;
    } | null | undefined;
    wholesaleDetails?: {
        businessName?: string | null | undefined;
        taxId?: string | null | undefined;
        discountPercentage?: number | null | undefined;
    } | null | undefined;
    rating?: {
        comment?: string | null | undefined;
        ratedAt?: NativeDate | null | undefined;
        score?: number | null | undefined;
    } | null | undefined;
}> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
export = _exports;
import mongoose = require("mongoose");
