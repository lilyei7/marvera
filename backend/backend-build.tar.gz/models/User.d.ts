declare const _exports: mongoose.Model<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    email?: unknown;
    firstName?: unknown;
    lastName?: unknown;
    password?: unknown;
    phone?: unknown;
    role?: unknown;
    address?: unknown;
    city?: unknown;
    postalCode?: unknown;
    isActive?: unknown;
    lastLogin?: unknown;
    notes?: unknown;
    dateOfBirth?: unknown;
    profileImage?: unknown;
    isEmailVerified?: unknown;
    emailVerificationToken?: unknown;
    passwordResetToken?: unknown;
    passwordResetExpires?: unknown;
    preferences?: unknown;
    loyaltyPoints?: unknown;
    totalOrders?: unknown;
    totalSpent?: unknown;
}, {}, {}, {}, mongoose.Document<unknown, {}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    email?: unknown;
    firstName?: unknown;
    lastName?: unknown;
    password?: unknown;
    phone?: unknown;
    role?: unknown;
    address?: unknown;
    city?: unknown;
    postalCode?: unknown;
    isActive?: unknown;
    lastLogin?: unknown;
    notes?: unknown;
    dateOfBirth?: unknown;
    profileImage?: unknown;
    isEmailVerified?: unknown;
    emailVerificationToken?: unknown;
    passwordResetToken?: unknown;
    passwordResetExpires?: unknown;
    preferences?: unknown;
    loyaltyPoints?: unknown;
    totalOrders?: unknown;
    totalSpent?: unknown;
}, {}, {
    timestamps: true;
    toJSON: {
        transform: (doc: mongoose.Document<unknown, {}, mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }, ret: mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }) => mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        };
    };
}> & {
    createdAt: NativeDate;
    updatedAt: NativeDate;
} & {
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<any, any> | unknown[] | mongoose.Types.DocumentArray<{
        [x: string]: unknown;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        [x: string]: unknown;
    }> & {
        [x: string]: unknown;
    }> | unknown[];
    email?: unknown;
    firstName?: unknown;
    lastName?: unknown;
    password?: unknown;
    phone?: unknown;
    role?: unknown;
    address?: unknown;
    city?: unknown;
    postalCode?: unknown;
    isActive?: unknown;
    lastLogin?: unknown;
    notes?: unknown;
    dateOfBirth?: unknown;
    profileImage?: unknown;
    isEmailVerified?: unknown;
    emailVerificationToken?: unknown;
    passwordResetToken?: unknown;
    passwordResetExpires?: unknown;
    preferences?: unknown;
    loyaltyPoints?: unknown;
    totalOrders?: unknown;
    totalSpent?: unknown;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    toJSON: {
        transform: (doc: mongoose.Document<unknown, {}, mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }, ret: mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        }) => mongoose.FlatRecord<{
            email: string;
            firstName: string;
            lastName: string;
            password: string;
            phone: string;
            role: "admin" | "customer" | "manager";
            isActive: boolean;
            isEmailVerified: boolean;
            loyaltyPoints: number;
            totalOrders: number;
            totalSpent: number;
            favoriteProducts: mongoose.Types.ObjectId[];
            shippingAddresses: mongoose.Types.DocumentArray<{
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }> & {
                name: string;
                phone: string;
                address: string;
                city: string;
                state: string;
                postalCode: string;
                isDefault: boolean;
            }>;
            address?: string | null | undefined;
            city?: string | null | undefined;
            postalCode?: string | null | undefined;
            lastLogin?: NativeDate | null | undefined;
            notes?: string | null | undefined;
            dateOfBirth?: NativeDate | null | undefined;
            profileImage?: string | null | undefined;
            emailVerificationToken?: string | null | undefined;
            passwordResetToken?: string | null | undefined;
            passwordResetExpires?: NativeDate | null | undefined;
            preferences?: {
                currency: "MXN" | "USD";
                language: "es" | "en";
                notifications?: {
                    email: boolean;
                    sms: boolean;
                    promotions: boolean;
                } | null | undefined;
            } | null | undefined;
        }> & {
            _id: mongoose.Types.ObjectId;
        } & {
            __v: number;
        };
    };
}, {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    phone: string;
    role: "admin" | "customer" | "manager";
    isActive: boolean;
    isEmailVerified: boolean;
    loyaltyPoints: number;
    totalOrders: number;
    totalSpent: number;
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<{
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }> & {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }>;
    address?: string | null | undefined;
    city?: string | null | undefined;
    postalCode?: string | null | undefined;
    lastLogin?: NativeDate | null | undefined;
    notes?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    profileImage?: string | null | undefined;
    emailVerificationToken?: string | null | undefined;
    passwordResetToken?: string | null | undefined;
    passwordResetExpires?: NativeDate | null | undefined;
    preferences?: {
        currency: "MXN" | "USD";
        language: "es" | "en";
        notifications?: {
            email: boolean;
            sms: boolean;
            promotions: boolean;
        } | null | undefined;
    } | null | undefined;
}, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    phone: string;
    role: "admin" | "customer" | "manager";
    isActive: boolean;
    isEmailVerified: boolean;
    loyaltyPoints: number;
    totalOrders: number;
    totalSpent: number;
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<{
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }> & {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }>;
    address?: string | null | undefined;
    city?: string | null | undefined;
    postalCode?: string | null | undefined;
    lastLogin?: NativeDate | null | undefined;
    notes?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    profileImage?: string | null | undefined;
    emailVerificationToken?: string | null | undefined;
    passwordResetToken?: string | null | undefined;
    passwordResetExpires?: NativeDate | null | undefined;
    preferences?: {
        currency: "MXN" | "USD";
        language: "es" | "en";
        notifications?: {
            email: boolean;
            sms: boolean;
            promotions: boolean;
        } | null | undefined;
    } | null | undefined;
}>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<{
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    phone: string;
    role: "admin" | "customer" | "manager";
    isActive: boolean;
    isEmailVerified: boolean;
    loyaltyPoints: number;
    totalOrders: number;
    totalSpent: number;
    favoriteProducts: mongoose.Types.ObjectId[];
    shippingAddresses: mongoose.Types.DocumentArray<{
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }> & {
        name: string;
        phone: string;
        address: string;
        city: string;
        state: string;
        postalCode: string;
        isDefault: boolean;
    }>;
    address?: string | null | undefined;
    city?: string | null | undefined;
    postalCode?: string | null | undefined;
    lastLogin?: NativeDate | null | undefined;
    notes?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    profileImage?: string | null | undefined;
    emailVerificationToken?: string | null | undefined;
    passwordResetToken?: string | null | undefined;
    passwordResetExpires?: NativeDate | null | undefined;
    preferences?: {
        currency: "MXN" | "USD";
        language: "es" | "en";
        notifications?: {
            email: boolean;
            sms: boolean;
            promotions: boolean;
        } | null | undefined;
    } | null | undefined;
}> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
export = _exports;
import mongoose = require("mongoose");
