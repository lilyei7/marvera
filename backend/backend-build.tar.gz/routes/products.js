"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const express_1 = tslib_1.__importDefault(require("express"));
const productService_1 = require("../services/productService");
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const router = express_1.default.Router();
// Obtener todas las categorías
router.get('/categories', async (req, res) => {
    try {
        const categories = await productService_1.ProductService.getAllCategories();
        res.json({
            success: true,
            categories
        });
    }
    catch (error) {
        console.error('Error obteniendo categorías:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Obtener todos los productos con filtros opcionales
router.get('/', async (req, res) => {
    try {
        const { category, search } = req.query;
        const categoryId = category ? parseInt(category) : undefined;
        const searchTerm = search;
        const products = await productService_1.ProductService.getAllProducts(categoryId, searchTerm);
        res.json({
            success: true,
            products
        });
    }
    catch (error) {
        console.error('Error obteniendo productos:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Obtener productos destacados
router.get('/featured', async (req, res) => {
    try {
        const products = await productService_1.ProductService.getFeaturedProducts();
        res.json({
            success: true,
            products
        });
    }
    catch (error) {
        console.error('Error obteniendo productos destacados:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Obtener producto por ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const productId = parseInt(id);
        if (isNaN(productId)) {
            return res.status(400).json({
                success: false,
                message: 'ID de producto inválido'
            });
        }
        const product = await productService_1.ProductService.getProductById(productId);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Producto no encontrado'
            });
        }
        res.json({
            success: true,
            product
        });
    }
    catch (error) {
        console.error('Error obteniendo producto:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Obtener producto por slug
router.get('/slug/:slug', async (req, res) => {
    try {
        const { slug } = req.params;
        const product = await productService_1.ProductService.getProductBySlug(slug);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Producto no encontrado'
            });
        }
        res.json({
            success: true,
            product
        });
    }
    catch (error) {
        console.error('Error obteniendo producto por slug:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Crear producto (solo admin)
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const productData = req.body;
        // Validación básica
        if (!productData.name || !productData.price || !productData.category_id) {
            return res.status(400).json({
                success: false,
                message: 'Nombre, precio y categoría son requeridos'
            });
        }
        // Generar slug si no se proporciona
        if (!productData.slug) {
            productData.slug = productData.name
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/(^-|-$)/g, '');
        }
        const product = await productService_1.ProductService.createProduct(productData);
        if (!product) {
            return res.status(400).json({
                success: false,
                message: 'Error creando producto'
            });
        }
        res.status(201).json({
            success: true,
            product
        });
    }
    catch (error) {
        console.error('Error creando producto:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Actualizar producto (solo admin)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const productId = parseInt(id);
        const updateData = req.body;
        if (isNaN(productId)) {
            return res.status(400).json({
                success: false,
                message: 'ID de producto inválido'
            });
        }
        const product = await productService_1.ProductService.updateProduct(productId, updateData);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Producto no encontrado'
            });
        }
        res.json({
            success: true,
            product
        });
    }
    catch (error) {
        console.error('Error actualizando producto:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
// Eliminar producto (solo admin)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const productId = parseInt(id);
        if (isNaN(productId)) {
            return res.status(400).json({
                success: false,
                message: 'ID de producto inválido'
            });
        }
        const success = await productService_1.ProductService.deleteProduct(productId);
        if (!success) {
            return res.status(404).json({
                success: false,
                message: 'Producto no encontrado'
            });
        }
        res.json({
            success: true,
            message: 'Producto eliminado correctamente'
        });
    }
    catch (error) {
        console.error('Error eliminando producto:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});
exports.default = router;
//# sourceMappingURL=products.js.map