"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const express_1 = tslib_1.__importDefault(require("express"));
const multer_1 = tslib_1.__importDefault(require("multer"));
const path_1 = tslib_1.__importDefault(require("path"));
const fs_1 = tslib_1.__importDefault(require("fs"));
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const router = express_1.default.Router();
// Crear directorio de uploads si no existe
const uploadsDir = path_1.default.join(__dirname, '../../uploads/images');
if (!fs_1.default.existsSync(uploadsDir)) {
    fs_1.default.mkdirSync(uploadsDir, { recursive: true });
}
// Test endpoint para verificar autenticación
router.get('/test', authenticateToken, requireAdmin, (req, res) => {
    res.json({
        success: true,
        message: 'Upload route working',
        user: req.user
    });
});
// Configurar multer para subir imágenes
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir); // Usar ruta absoluta
    },
    filename: (req, file, cb) => {
        // Generar nombre único para el archivo
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'product-' + uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
// Filtro para solo permitir imágenes
const fileFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
        cb(null, true);
    }
    else {
        cb(new Error('Solo se permiten archivos de imagen'), false);
    }
};
const upload = (0, multer_1.default)({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 25 * 1024 * 1024 // 25MB máximo por archivo
    }
});
// Simple test endpoint sin autenticación
router.post('/test-cors', (req, res) => {
    res.json({
        success: true,
        message: 'CORS working fine',
        timestamp: new Date().toISOString()
    });
});
// Endpoint para subir múltiples imágenes
router.post('/upload', authenticateToken, requireAdmin, upload.array('images', 5), (req, res) => {
    try {
        if (!req.files || !Array.isArray(req.files)) {
            return res.status(400).json({
                success: false,
                message: 'No se subieron archivos'
            });
        }
        const imageUrls = req.files.map((file) => {
            return `/uploads/images/${file.filename}`;
        });
        res.json({
            success: true,
            message: 'Imágenes subidas correctamente',
            images: imageUrls
        });
    }
    catch (error) {
        console.error('Error uploading images:', error);
        res.status(500).json({
            success: false,
            message: 'Error al subir las imágenes'
        });
    }
});
// Endpoint para subir una sola imagen
router.post('/upload-single', authenticateToken, requireAdmin, upload.single('image'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No se subió ningún archivo'
            });
        }
        const imageUrl = `/uploads/images/${req.file.filename}`;
        res.json({
            success: true,
            message: 'Imagen subida correctamente',
            imageUrl: imageUrl
        });
    }
    catch (error) {
        console.error('Error uploading image:', error);
        res.status(500).json({
            success: false,
            message: 'Error al subir la imagen'
        });
    }
});
exports.default = router;
//# sourceMappingURL=upload.js.map