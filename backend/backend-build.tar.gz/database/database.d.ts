import { Database } from 'sqlite3';
export declare class DatabaseManager {
    private db;
    constructor();
    private initializeTables;
    private insertDefaultCategories;
    private insertDefaultProducts;
    private insertDefaultBranches;
    private createAdminUser;
    getDb(): Database;
    close(): void;
}
export declare const dbManager: DatabaseManager;
