"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchService = void 0;
const tslib_1 = require("tslib");
const prisma_1 = tslib_1.__importDefault(require("../lib/prisma"));
const client_1 = require("@prisma/client");
class BranchService {
    // Obtener todas las sucursales (para admin)
    static async getAllBranches() {
        return prisma_1.default.branch.findMany({
            orderBy: { createdAt: 'desc' }
        });
    }
    // Obtener solo sucursales activas (para público)
    static async getActiveBranches() {
        return prisma_1.default.branch.findMany({
            where: { isActive: true },
            orderBy: { name: 'asc' }
        });
    }
    // Obtener sucursal por ID
    static async getBranchById(id) {
        return prisma_1.default.branch.findUnique({
            where: { id }
        });
    }
    // Crear nueva sucursal
    static async createBranch(data) {
        return prisma_1.default.branch.create({
            data
        });
    }
    // Actualizar sucursal
    static async updateBranch(id, data) {
        try {
            return await prisma_1.default.branch.update({
                where: { id },
                data
            });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === 'P2025') {
                return null; // Registro no encontrado
            }
            throw error;
        }
    }
    // Eliminar sucursal
    static async deleteBranch(id) {
        try {
            await prisma_1.default.branch.delete({
                where: { id }
            });
            return true;
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === 'P2025') {
                return false; // Registro no encontrado
            }
            throw error;
        }
    }
    // Alternar estado activo/inactivo
    static async toggleBranchStatus(id) {
        const branch = await this.getBranchById(id);
        if (!branch)
            return null;
        return prisma_1.default.branch.update({
            where: { id },
            data: { isActive: !branch.isActive }
        });
    }
    // Buscar sucursales por nombre o dirección
    static async searchBranches(query) {
        return prisma_1.default.branch.findMany({
            where: {
                OR: [
                    {
                        name: {
                            contains: query
                        }
                    },
                    {
                        address: {
                            contains: query
                        }
                    }
                ],
                isActive: true
            },
            orderBy: { name: 'asc' }
        });
    }
    // Buscar sucursales cercanas (por coordenadas)
    static async getNearbyBranches(latitude, longitude, radiusKm = 10) {
        // Para SQLite, hacemos una búsqueda simple por ahora
        // En producción se podría usar PostGIS con PostgreSQL
        const branches = await prisma_1.default.branch.findMany({
            where: {
                isActive: true,
                latitude: { not: null },
                longitude: { not: null }
            }
        });
        // Filtrar por distancia usando la fórmula de Haversine
        return branches.filter(branch => {
            if (!branch.latitude || !branch.longitude)
                return false;
            const distance = this.calculateDistance(latitude, longitude, branch.latitude, branch.longitude);
            return distance <= radiusKm;
        });
    }
    // Calcular distancia entre dos puntos (Haversine)
    static calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Radio de la Tierra en km
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c;
        return distance;
    }
    static deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
}
exports.BranchService = BranchService;
//# sourceMappingURL=branchService.js.map