"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductService = void 0;
const tslib_1 = require("tslib");
const prisma_1 = tslib_1.__importDefault(require("../lib/prisma"));
class ProductService {
    static async getAllCategories() {
        try {
            const categories = await prisma_1.default.category.findMany({
                where: { isActive: true },
                orderBy: { name: 'asc' }
            });
            return categories;
        }
        catch (error) {
            console.error('Error obteniendo categorías:', error);
            return [];
        }
    }
    static async getAllProducts(categoryId, search) {
        try {
            const where = { isActive: true };
            if (categoryId) {
                where.categoryId = categoryId;
            }
            if (search) {
                where.OR = [
                    { name: { contains: search, mode: 'insensitive' } },
                    { description: { contains: search, mode: 'insensitive' } }
                ];
            }
            const products = await prisma_1.default.product.findMany({
                where,
                include: {
                    category: {
                        select: { name: true }
                    }
                },
                orderBy: [
                    { isFeatured: 'desc' },
                    { name: 'asc' }
                ]
            });
            return products.map(product => ({
                ...product,
                categoryName: product.category?.name,
                category_id: product.categoryId,
                images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
            }));
        }
        catch (error) {
            console.error('Error obteniendo productos:', error);
            return [];
        }
    }
    static async getFeaturedProducts() {
        try {
            const products = await prisma_1.default.product.findMany({
                where: {
                    isActive: true,
                    isFeatured: true
                },
                include: {
                    category: {
                        select: { name: true }
                    }
                },
                orderBy: { name: 'asc' },
                take: 6
            });
            return products.map(product => ({
                ...product,
                categoryName: product.category?.name,
                category_id: product.categoryId,
                images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
            }));
        }
        catch (error) {
            console.error('Error obteniendo productos destacados:', error);
            return [];
        }
    }
    static async getProductById(id) {
        try {
            const product = await prisma_1.default.product.findFirst({
                where: {
                    id: id,
                    isActive: true
                },
                include: {
                    category: {
                        select: { name: true }
                    }
                }
            });
            if (product) {
                return {
                    ...product,
                    categoryName: product.category?.name,
                    category_id: product.categoryId,
                    images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
                };
            }
            return null;
        }
        catch (error) {
            console.error('Error obteniendo producto:', error);
            return null;
        }
    }
    static async getProductBySlug(slug) {
        try {
            const product = await prisma_1.default.product.findFirst({
                where: {
                    slug: slug,
                    isActive: true
                },
                include: {
                    category: {
                        select: { name: true }
                    }
                }
            });
            if (product) {
                return {
                    ...product,
                    categoryName: product.category?.name,
                    category_id: product.categoryId,
                    images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
                };
            }
            return null;
        }
        catch (error) {
            console.error('Error obteniendo producto por slug:', error);
            return null;
        }
    }
    static async createProduct(productData) {
        try {
            const product = await prisma_1.default.product.create({
                data: {
                    name: productData.name,
                    slug: productData.slug,
                    description: productData.description,
                    price: productData.price,
                    comparePrice: productData.comparePrice,
                    categoryId: productData.category_id,
                    stock: productData.stock,
                    unit: productData.unit,
                    images: JSON.stringify(Array.isArray(productData.images) ? productData.images : []),
                    isActive: productData.isActive,
                    isFeatured: productData.isFeatured
                },
                include: {
                    category: {
                        select: { name: true }
                    }
                }
            });
            return {
                ...product,
                categoryName: product.category?.name,
                category_id: product.categoryId,
                images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
            };
        }
        catch (error) {
            console.error('Error creando producto:', error);
            return null;
        }
    }
    static async updateProduct(id, productData) {
        try {
            const updateData = {};
            if (productData.name)
                updateData.name = productData.name;
            if (productData.description !== undefined)
                updateData.description = productData.description;
            if (productData.price !== undefined)
                updateData.price = productData.price;
            if (productData.stock !== undefined)
                updateData.stock = productData.stock;
            if (productData.images !== undefined) {
                updateData.images = JSON.stringify(Array.isArray(productData.images) ? productData.images : []);
            }
            const product = await prisma_1.default.product.update({
                where: { id },
                data: updateData,
                include: {
                    category: {
                        select: { name: true }
                    }
                }
            });
            return {
                ...product,
                categoryName: product.category?.name,
                category_id: product.categoryId,
                images: typeof product.images === 'string' ? JSON.parse(product.images) : (product.images || [])
            };
        }
        catch (error) {
            console.error('Error actualizando producto:', error);
            return null;
        }
    }
    static async deleteProduct(id) {
        try {
            // Verificar que el producto existe
            const product = await ProductService.getProductById(id);
            if (!product) {
                return false;
            }
            await prisma_1.default.product.update({
                where: { id },
                data: { isActive: false }
            });
            return true;
        }
        catch (error) {
            console.error('Error eliminando producto:', error);
            return false;
        }
    }
}
exports.ProductService = ProductService;
//# sourceMappingURL=productService.js.map