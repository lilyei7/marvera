import { Branch, Prisma } from '@prisma/client';
export type BranchCreateInput = Prisma.BranchCreateInput;
export type BranchUpdateInput = Prisma.BranchUpdateInput;
export declare class BranchService {
    static getAllBranches(): Promise<Branch[]>;
    static getActiveBranches(): Promise<Branch[]>;
    static getBranchById(id: number): Promise<Branch | null>;
    static createBranch(data: BranchCreateInput): Promise<Branch>;
    static updateBranch(id: number, data: BranchUpdateInput): Promise<Branch | null>;
    static deleteBranch(id: number): Promise<boolean>;
    static toggleBranchStatus(id: number): Promise<Branch | null>;
    static searchBranches(query: string): Promise<Branch[]>;
    static getNearbyBranches(latitude: number, longitude: number, radiusKm?: number): Promise<Branch[]>;
    private static calculateDistance;
    private static deg2rad;
}
