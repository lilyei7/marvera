import { Order } from '../types';
export declare class OrderService {
    static createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'updatedAt'>): Promise<Order | null>;
    static getOrderById(id: number): Promise<Order | null>;
    static getOrdersByUserId(userId: number): Promise<Order[]>;
    static getAllOrders(): Promise<Order[]>;
    static updateOrderStatus(orderId: number, status: Order['status']): Promise<Order | null>;
    static assignDriver(orderId: number, driverId: number): Promise<Order | null>;
    private static generateOrderNumber;
}
