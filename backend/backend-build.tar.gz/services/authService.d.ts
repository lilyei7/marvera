import { LoginRequest, RegisterRequest, AuthResponse } from '../types';
export declare class AuthService {
    static register(userData: RegisterRequest): Promise<AuthResponse>;
    static login(loginData: LoginRequest): Promise<AuthResponse>;
    static verifyToken(token: string): any;
    static getUserById(userId: number): Promise<any | null>;
    static createAdminUser(): Promise<void>;
}
