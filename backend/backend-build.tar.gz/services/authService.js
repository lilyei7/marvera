"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const tslib_1 = require("tslib");
const bcryptjs_1 = tslib_1.__importDefault(require("bcryptjs"));
const jsonwebtoken_1 = tslib_1.__importDefault(require("jsonwebtoken"));
const prisma_1 = tslib_1.__importDefault(require("../lib/prisma"));
const JWT_SECRET = process.env.JWT_SECRET || 'marvera-jwt-secret-key-2025';
const JWT_EXPIRES_IN = '7d';
class AuthService {
    static async register(userData) {
        try {
            // Verificar si el usuario ya existe
            const existingUser = await prisma_1.default.user.findUnique({
                where: { email: userData.email }
            });
            if (existingUser) {
                return {
                    success: false,
                    message: 'El email ya está registrado'
                };
            }
            // Encriptar contraseña
            const hashedPassword = await bcryptjs_1.default.hash(userData.password, 10);
            // Crear usuario
            const newUser = await prisma_1.default.user.create({
                data: {
                    email: userData.email,
                    password: hashedPassword,
                    firstName: userData.firstName,
                    lastName: userData.lastName,
                    phone: userData.phone || null,
                    address: userData.address || null,
                    role: 'CUSTOMER'
                },
                select: {
                    id: true,
                    email: true,
                    firstName: true,
                    lastName: true,
                    phone: true,
                    address: true,
                    role: true,
                    isActive: true,
                    createdAt: true
                }
            });
            // Generar token
            const token = jsonwebtoken_1.default.sign({ userId: newUser.id, email: newUser.email, role: newUser.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
            return {
                success: true,
                token,
                user: newUser
            };
        }
        catch (error) {
            console.error('Error en registro:', error);
            return {
                success: false,
                message: 'Error interno del servidor'
            };
        }
    }
    static async login(loginData) {
        try {
            // Buscar usuario
            const user = await prisma_1.default.user.findFirst({
                where: {
                    email: loginData.email,
                    isActive: true
                }
            });
            if (!user) {
                return {
                    success: false,
                    message: 'Credenciales inválidas'
                };
            }
            // Verificar contraseña
            const isValidPassword = await bcryptjs_1.default.compare(loginData.password, user.password);
            if (!isValidPassword) {
                return {
                    success: false,
                    message: 'Credenciales inválidas'
                };
            }
            // Generar token
            const token = jsonwebtoken_1.default.sign({ userId: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
            // Remover password del response
            const { password, ...userWithoutPassword } = user;
            return {
                success: true,
                token,
                user: userWithoutPassword
            };
        }
        catch (error) {
            console.error('Error en login:', error);
            return {
                success: false,
                message: 'Error interno del servidor'
            };
        }
    }
    static verifyToken(token) {
        try {
            console.log('🔐 AuthService.verifyToken - Token a verificar:', token.substring(0, 20) + '...');
            console.log('🔐 AuthService.verifyToken - JWT_SECRET:', JWT_SECRET ? 'Secret presente' : 'Secret faltante');
            const decoded = jsonwebtoken_1.default.verify(token, JWT_SECRET);
            console.log('🔐 AuthService.verifyToken - Token válido, decoded:', decoded);
            return decoded;
        }
        catch (error) {
            console.error('🔐 AuthService.verifyToken - Error:', error);
            return null;
        }
    }
    static async getUserById(userId) {
        try {
            console.log('🔐 AuthService.getUserById - Buscando usuario ID:', userId);
            const user = await prisma_1.default.user.findUnique({
                where: { id: userId },
                select: {
                    id: true,
                    email: true,
                    firstName: true,
                    lastName: true,
                    phone: true,
                    role: true,
                    isActive: true,
                    createdAt: true
                }
            });
            console.log('🔐 AuthService.getUserById - Usuario encontrado:', user ? `ID ${user.id}, role: ${user.role}, active: ${user.isActive}` : 'No encontrado');
            return user;
        }
        catch (error) {
            console.error('🔐 AuthService.getUserById - Error:', error);
            return null;
        }
    }
    static async createAdminUser() {
        try {
            // Verificar si ya existe un admin
            const existingAdmin = await prisma_1.default.user.findFirst({
                where: {
                    email: 'admin',
                    role: 'ADMIN'
                }
            });
            if (existingAdmin) {
                console.log('✅ Usuario admin ya existe en la base de datos');
                return;
            }
            // Crear usuario admin
            console.log('🔨 Creando usuario admin...');
            const hashedPassword = await bcryptjs_1.default.hash('admin', 10);
            await prisma_1.default.user.create({
                data: {
                    email: 'admin',
                    password: hashedPassword,
                    firstName: 'Administrador',
                    lastName: 'MarVera',
                    role: 'ADMIN',
                    isActive: true
                }
            });
            console.log('✅ Usuario admin creado - email: admin, password: admin');
        }
        catch (error) {
            console.error('❌ Error creando usuario admin:', error);
        }
    }
}
exports.AuthService = AuthService;
//# sourceMappingURL=authService.js.map