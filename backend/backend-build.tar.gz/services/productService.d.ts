import { Product, Category } from '../types';
export declare class ProductService {
    static getAllCategories(): Promise<Category[]>;
    static getAllProducts(categoryId?: number, search?: string): Promise<Product[]>;
    static getFeaturedProducts(): Promise<Product[]>;
    static getProductById(id: number): Promise<Product | null>;
    static getProductBySlug(slug: string): Promise<Product | null>;
    static createProduct(productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product | null>;
    static updateProduct(id: number, productData: Partial<Product>): Promise<Product | null>;
    static deleteProduct(id: number): Promise<boolean>;
}
