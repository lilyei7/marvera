"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderService = void 0;
const tslib_1 = require("tslib");
const prisma_1 = tslib_1.__importDefault(require("../lib/prisma"));
class OrderService {
    static async createOrder(orderData) {
        try {
            // Generar número de orden único
            const orderNumber = this.generateOrderNumber();
            const order = await prisma_1.default.order.create({
                data: {
                    orderNumber,
                    userId: orderData.user_id,
                    status: orderData.status || 'pending',
                    subtotal: orderData.subtotal,
                    shippingCost: orderData.shippingCost || 0,
                    tax: orderData.tax || 0,
                    total: orderData.total,
                    paymentMethod: orderData.paymentMethod || null,
                    paymentStatus: orderData.paymentStatus || 'pending',
                    shippingAddress: orderData.shippingAddress || null,
                    notes: orderData.notes || null,
                    orderItems: orderData.items ? {
                        create: orderData.items.map(item => ({
                            productId: item.product_id,
                            quantity: item.quantity,
                            price: item.price,
                            total: item.price * item.quantity
                        }))
                    } : undefined
                },
                include: {
                    user: {
                        select: {
                            firstName: true,
                            lastName: true,
                            email: true
                        }
                    },
                    driver: {
                        select: {
                            firstName: true,
                            lastName: true
                        }
                    },
                    orderItems: {
                        include: {
                            product: {
                                select: {
                                    name: true,
                                    unit: true
                                }
                            }
                        }
                    }
                }
            });
            return {
                id: order.id,
                orderNumber: order.orderNumber,
                user_id: order.userId,
                status: order.status,
                subtotal: order.subtotal,
                shippingCost: order.shippingCost,
                tax: order.tax,
                total: order.total,
                paymentMethod: order.paymentMethod || undefined,
                paymentStatus: order.paymentStatus,
                shippingAddress: order.shippingAddress || undefined,
                deliveryDate: order.deliveryDate || undefined,
                driver_id: order.driverId || undefined,
                trackingCode: order.trackingCode || undefined,
                notes: order.notes || undefined,
                createdAt: order.createdAt,
                updatedAt: order.updatedAt,
                items: order.orderItems?.map(item => ({
                    id: item.id,
                    product_id: item.productId,
                    order_id: item.orderId,
                    productName: item.product?.name,
                    quantity: item.quantity,
                    price: item.price
                })) || []
            };
        }
        catch (error) {
            console.error('Error creando orden:', error);
            return null;
        }
    }
    static async getOrderById(id) {
        try {
            const order = await prisma_1.default.order.findUnique({
                where: { id },
                include: {
                    user: {
                        select: {
                            firstName: true,
                            lastName: true,
                            email: true
                        }
                    },
                    driver: {
                        select: {
                            firstName: true,
                            lastName: true
                        }
                    },
                    orderItems: {
                        include: {
                            product: {
                                select: {
                                    name: true,
                                    unit: true
                                }
                            }
                        }
                    }
                }
            });
            if (!order)
                return null;
            return {
                id: order.id,
                orderNumber: order.orderNumber,
                user_id: order.userId,
                status: order.status,
                subtotal: order.subtotal,
                shippingCost: order.shippingCost,
                tax: order.tax,
                total: order.total,
                paymentMethod: order.paymentMethod || undefined,
                paymentStatus: order.paymentStatus,
                shippingAddress: order.shippingAddress || undefined,
                deliveryDate: order.deliveryDate || undefined,
                driver_id: order.driverId || undefined,
                trackingCode: order.trackingCode || undefined,
                notes: order.notes || undefined,
                createdAt: order.createdAt,
                updatedAt: order.updatedAt,
                items: order.orderItems?.map(item => ({
                    id: item.id,
                    product_id: item.productId,
                    order_id: item.orderId,
                    productName: item.product?.name,
                    quantity: item.quantity,
                    price: item.price
                })) || []
            };
        }
        catch (error) {
            console.error('Error obteniendo orden:', error);
            return null;
        }
    }
    static async getOrdersByUserId(userId) {
        try {
            const orders = await prisma_1.default.order.findMany({
                where: { userId },
                include: {
                    driver: {
                        select: {
                            firstName: true,
                            lastName: true
                        }
                    },
                    orderItems: {
                        include: {
                            product: {
                                select: {
                                    name: true,
                                    unit: true
                                }
                            }
                        }
                    }
                },
                orderBy: { createdAt: 'desc' }
            });
            return orders.map(order => ({
                id: order.id,
                orderNumber: order.orderNumber,
                user_id: order.userId,
                status: order.status,
                subtotal: order.subtotal,
                shippingCost: order.shippingCost,
                tax: order.tax,
                total: order.total,
                paymentMethod: order.paymentMethod || undefined,
                paymentStatus: order.paymentStatus,
                shippingAddress: order.shippingAddress || undefined,
                deliveryDate: order.deliveryDate || undefined,
                driver_id: order.driverId || undefined,
                trackingCode: order.trackingCode || undefined,
                notes: order.notes || undefined,
                createdAt: order.createdAt,
                updatedAt: order.updatedAt,
                items: order.orderItems?.map(item => ({
                    id: item.id,
                    product_id: item.productId,
                    order_id: item.orderId,
                    productName: item.product?.name,
                    quantity: item.quantity,
                    price: item.price
                })) || []
            }));
        }
        catch (error) {
            console.error('Error obteniendo órdenes del usuario:', error);
            return [];
        }
    }
    static async getAllOrders() {
        try {
            const orders = await prisma_1.default.order.findMany({
                include: {
                    user: {
                        select: {
                            firstName: true,
                            lastName: true,
                            email: true
                        }
                    },
                    driver: {
                        select: {
                            firstName: true,
                            lastName: true
                        }
                    },
                    orderItems: {
                        include: {
                            product: {
                                select: {
                                    name: true,
                                    unit: true
                                }
                            }
                        }
                    }
                },
                orderBy: { createdAt: 'desc' }
            });
            return orders.map(order => ({
                id: order.id,
                orderNumber: order.orderNumber,
                user_id: order.userId,
                status: order.status,
                subtotal: order.subtotal,
                shippingCost: order.shippingCost,
                tax: order.tax,
                total: order.total,
                paymentMethod: order.paymentMethod || undefined,
                paymentStatus: order.paymentStatus,
                shippingAddress: order.shippingAddress || undefined,
                deliveryDate: order.deliveryDate || undefined,
                driver_id: order.driverId || undefined,
                trackingCode: order.trackingCode || undefined,
                notes: order.notes || undefined,
                createdAt: order.createdAt,
                updatedAt: order.updatedAt,
                items: order.orderItems?.map(item => ({
                    id: item.id,
                    product_id: item.productId,
                    order_id: item.orderId,
                    productName: item.product?.name,
                    quantity: item.quantity,
                    price: item.price
                })) || []
            }));
        }
        catch (error) {
            console.error('Error obteniendo todas las órdenes:', error);
            return [];
        }
    }
    static async updateOrderStatus(orderId, status) {
        try {
            await prisma_1.default.order.update({
                where: { id: orderId },
                data: { status }
            });
            return await this.getOrderById(orderId);
        }
        catch (error) {
            console.error('Error actualizando estado de orden:', error);
            return null;
        }
    }
    static async assignDriver(orderId, driverId) {
        try {
            await prisma_1.default.order.update({
                where: { id: orderId },
                data: {
                    driverId: driverId,
                    status: 'shipped'
                }
            });
            return await this.getOrderById(orderId);
        }
        catch (error) {
            console.error('Error asignando conductor:', error);
            return null;
        }
    }
    static generateOrderNumber() {
        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).substr(2, 5);
        return `MV-${timestamp}-${random}`.toUpperCase();
    }
}
exports.OrderService = OrderService;
//# sourceMappingURL=orderService.js.map